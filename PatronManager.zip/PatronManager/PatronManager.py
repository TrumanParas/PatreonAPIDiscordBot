# This discord bot acts as a verification gate by using Patreon information. It logs user information on an external
# text file. It also sends logs to a desired channel in the server. It doesn't immediately kick users that fail the
# verification. It gets a nickname for new users before they enter the server.
# The bot can send out a pm to all unverified users, asking for their patreon. This should really only
# be called once, at the moment the bot enters the server.
# The bot also checks to see who has yet to verify themselves and can kick those who haven't by calling a command.
# Written by: Truman Paras

import discord
import patreon
import asyncio
import os  # environment variables
from discord.ext import commands
from discord.utils import get

# Replace global variables with whatever you desire. Set the
SERVER_NAME = 'Feral Heart Unleashed Patreon'
MODERATOR_ROLE = 'chad'
LOG_CHANNEL = 848778547585613844
FILE_NAME = 'users.txt'

intents = discord.Intents().default()  # this tells our client that we want to know who joins the server
intents.members = True
client = commands.Bot(command_prefix='.', intents=intents)  # create the bot, commands start with a .

# check if the bot is running
@client.event
async def on_ready():
    print("Ready")


# For when a new member joins. This function greets them, verifies them, and gets their username for the game.
# All their data is appended to the FILE_NAME file, which keeps log of all verified users
# I'm not sure how to make the user's in game account yet
@client.event
async def on_member_join(member):
    # First, get the channel to send logs to and inform of a new user trying to access the server
    log_channel = client.get_channel(LOG_CHANNEL)
    log_string = f'----------- BEGINNING OF LOG -----------\nNew user {member.mention} is beginning verification.\n'

    discord_id = member.id
    users_list = []
    data = get_discord_members()
    for item in data:  # idk why but python likes it when I fill the list instead of doing users_list = get_discord_members()
        users_list.append(item[0])
    found = False
    tries = 0
    # Send the user their first message
    await member.send(f'Welcome to the ' + SERVER_NAME + f' server, {member.mention}! :partying_face:'
                      f'\nFirst I need you to message me in this chat so I can configure myself. Say literally anything.')
    try:
        # Get the context
        msg = await client.wait_for('message', check=None, timeout=100)
        ctx = await client.get_context(msg)
        # Get patreon name and check if valid
        await member.send(f'Thank you :smile:\nNow I need to verify you. Please type in your name as it\'s listed on '
                          f'Patreon.')
        name = await client.wait_for('message', check=lambda message: message.author == ctx.author, timeout=180)
        name = name.content
        await member.send(f'Great! Now I can start my search. This might take a minute.\nSearching for patron...')
        # Get a list of all patreon members and see if the given name matches
        all_pledges = get_patron_names()
        #  If the name matches the user input, let them in, otherwise, give them a few tries
        for pledge in all_pledges:
            if name == pledge:
                found = True
                for user in users_list:  # check if the name given has already been used to verify a member
                    if user == name:
                        log_string += f':red_circle: User {member.mention} attempted to use the Patreon name \'' + name + '\' to get access. That name has already been used to verify someone.\n'
                        found = False
        # I'm giving them three tries
        if not found:
            tries += 1
            while tries < 3 and not found:
                await member.send(f'It doesn\'t look like that was a valid patron name :face_with_raised_eyebrow:\n'
                                  f'Please try again. After this, you have ' + str(2 - tries) + ' tries left')
                name = await client.wait_for('message', check=lambda message: message.author == ctx.author, timeout=180)
                name = name.content
                for pledge in all_pledges:
                    if name == pledge:
                        found = True
                        for user in users_list:  # check if the name given has already been used to verify a member
                            if user == name:
                                log_string += f':red_cirlce: User {member.mention} attempted to use the Patreon name \'' + name + '\' to get access. That name has already been used to verify someone.\n'
                                found = False
                tries += 1
        # do not verify them and send a log of their status in discord purgatory
        if not found:
            log_string += f':red_circle: New user {member.mention} did not provide a valid Patreon - not given access.\n--------------- END OF LOG ---------------'
            await member.send("You are not being given access to the server. Please contact server moderators if this "
                              "is a mistake. We apologise for any inconvenience")
            await log_channel.send(log_string)
            return 0

        # They've been verified, so get their discord name
        log_string += f'New user {member.mention} is verified.\n'
        await member.send(f'You have been verified :white_check_mark:\nNow I want to know if you want a nickname for '
                          f'the server (y/n)')
        choice = await client.wait_for('message', check=lambda message: message.author == ctx.author, timeout=10000)
        choice = choice.content
        while choice.lower() != 'n' and choice.lower() != 'y':
            await member.send(f'Please respond with a (y/n)')
            choice = await client.wait_for('message', check=lambda message: message.author == ctx.author, timeout=10000)
            choice = choice.content
        if choice.lower() == 'y':
            await member.send(f'What will your nickname be?')
            nickname = await client.wait_for('message', check=lambda message: message.author == ctx.author, timeout=10000)
            nickname = nickname.content
            await member.edit(nick=nickname)

        # Send their final message and send a log
        log_string += f'New user {member.mention} now has access to the server.\n--------------- END OF LOG ---------------'
        await member.send(f'Perfect! You\'ve been given access to the server. We hope you enjoy your stay!')

        # Record the new member and give them the VERIFIED role
        record_discord_member(name, discord_id)
        role = get(member.guild.roles, name="VERIFIED")
        await member.add_roles(role)

        # Send the log
        await log_channel.send(log_string)

    # Timed out, send a log, do not verify them
    except asyncio.TimeoutError:
        log_string += f':red_circle: New user {member.mention} timed out - not given access.\n--------------- END OF LOG ---------------'
        # Send the log
        await log_channel.send(log_string)
        await member.send("You are not being given access to the server because you timed out. Please contact server "
                          "moderators if this is a mistake. We apologise for any inconvenience")


# When a member leaves, we need to remove their data off the FILE_NAME file. We also need to delete their game account
@client.event
async def on_member_remove(member):
    log_channel = client.get_channel(LOG_CHANNEL)
    await log_channel.send(f'Member {member.mention} has left the server')
    # this block of code scans each line of the users file and re-writes all data we want to keep back into the file
    del_line = member.id
    data = get_discord_members()
    f = open(FILE_NAME, "w")
    if len(data) > 0:
        for item in data:
            if int(item[1]) != del_line:
                f.write(item[0] + "," + item[1] + "\n")
    f.close()


# using the patreon access token, get all the full names of all the patrons
def get_patron_names():
    access_token = os.environ.get('ACCESS_KEY_PATREON')  # Creator's Acess Token off your Patreon campaign, saved as an environment variable called ACCESS_KEY_PATREON
    api_client = patreon.API(access_token)               # set up patreon client
    campaign_response = api_client.fetch_campaign()
    campaign_id = campaign_response.data()[0].id()
    all_pledges = []
    verified_pledge = []
    cursor = None
    while True:
        pledges_response = api_client.fetch_page_of_pledges(campaign_id, 1, cursor=cursor,
                                                            fields={'pledge': 'declined_since'})
        cursor = api_client.extract_cursor(pledges_response)
        all_pledges += pledges_response.data()
        if not cursor:
            break

    # check if their cards were declined (no longer a patron)
    for pledge in all_pledges:
        declined = pledge.attribute('declined_since')
        if declined:
            all_pledges.remove(pledge)

    # Now all the remaining
    for pledge in all_pledges:
        pledge_name = pledge.relationship('patron').attribute('full_name')
        verified_pledge.append(pledge_name)

    return verified_pledge


# adds the full name and id of a verified patron to a file for a simple solution to keeping track of what patron names
# have been used to grant people access to the discord
def record_discord_member(patron_full_name, discord_id):
    try:
        f = open(FILE_NAME, "a")
        f.write(patron_full_name + "," + str(discord_id) + "\n")
        f.close()
    except IOError:
        print("Error opening " + FILE_NAME + " - IOError.")


# returns a list of lists of the full names of every patron verified on the server and their discord id.
# This function will be called when checking if a new member has given a unique patron name that hasn't been used yet
def get_discord_members():
    user_list = []
    try:
        if os.path.getsize(FILE_NAME) != 0:  # if the file isn't empty
            with open(FILE_NAME, 'r') as f:
                for line in f:
                    if line != '\n':
                        line_append = line.strip().split(',')
                        user_list.append(line_append)
        return user_list
    except IOError:
        print("Error opening " + FILE_NAME + " - IOError.")


# Moderators use this command to send out messages to those who aren't verified, but already in the server
@client.command(pass_context=True)
async def verify_server_members(ctx):
    num_flags = 0
    log_channel = client.get_channel(LOG_CHANNEL)
    data = get_discord_members()
    if MODERATOR_ROLE in [i.name.lower() for i in ctx.author.roles]:
        # If the list of data isn't empty, do the following
        members = ctx.guild.members
        for member in members:
            # skip if the member is a mod or another bot
            if MODERATOR_ROLE not in [i.name.lower() for i in member.roles] and not member.bot:
                verified = False
                if len(data) > 0:   # if the list isn't empty
                    for item in data:
                        if item[1] == member.id:
                            verified = True
                if not verified:
                    try:
                        await member.send(f'Hi {member.mention},\nI\'m a bot for the ' + SERVER_NAME + ' server, and for being a '
                                          f'member of this community, I need to verify that you have a valid patreon. Please respond '
                                          f'to me with the command .patreon_name Your Name Here.')
                    except:
                        await log_channel.send(f':red_circle: Error sending {member.mention} a verification message. Requires '
                                               f'further actions')
                        num_flags += 1

    # Do not have permission, send log of attempt
    else:
        await log_channel.send(f':red_circle: Member {ctx.author.mention} tried to use the verify_server_members command'
                               f' without permission')
    if num_flags == 0:
        await ctx.send("Command successful")


# This command will return a list in the chat of all the names of the members in the discord that are not verified
# Only moderators can use this command
@client.command(pass_context=True)
async def get_unverified(ctx):
    log_channel = client.get_channel(LOG_CHANNEL)
    # check if the member calling this is a moderator
    if MODERATOR_ROLE.lower() in [i.name.lower() for i in ctx.author.roles]:
        members = ctx.guild.members
        data = get_discord_members()
        unverified = []
        # skip if the member is a mod or another bot and then check if their discord id has been recorded in the file
        for member in members:
            if MODERATOR_ROLE.lower() not in [i.name.lower() for i in member.roles] and not member.bot:
                found = False
                for item in data:
                    if item[1] == member.id:
                        found = True
                if not found:
                    # if a member's discord id is not in the file, append their display name to the list
                    unverified.append(member.display_name)
        # In the same chat as the command, send the users not verified
        await ctx.send('\n'.join(unverified))
    else:
        await log_channel.send(f':red_circle: Member {ctx.author.mention} tried to execute the get_verified command.')


# Users use this command to verify themselves. It requests a patreon name as an argument
@client.command(pass_context=True)
async def patreon_name(ctx, *name):
    # Format name
    name = ' '.join(name)
    await ctx.author.send("This might take a minute.\nAuthenticating...")
    # get a channel to log to and a list of users that have already been verified
    log_channel = client.get_channel(LOG_CHANNEL)
    discord_id = ctx.author.id
    users_list = []
    data = get_discord_members()
    for item in data:  # idk why but python likes it when I fill the list instead of doing users_list = get_discord_members()
        users_list.append(item[0])
    found = False

    # check if the response has already been used. If it has, send a log and a message and return
    for patreon_user in users_list:
        if patreon_user == name:
            await ctx.author.send("Invalid patreon. Please try the command again or contact a moderator immediately.")
            await log_channel.send(f':red_circle: User {ctx.author.mention} used the name \'' + name + '\' to try '
                                    'verifying themselves, but that name is already used.')
            return 0

    # Get a list of all patreon members
    all_pledges = get_patron_names()
    # If a patreon name matches the user input, add them to the FILE_NAME list. If not, log and return
    for pledge in all_pledges:
        if name == pledge:
            found = True

    # send resulting messages and logs depending on if the patreon exists
    if not found:
        await ctx.author.send("Patreon not found. Please try the .patreon_name command again or contact server "
                              "moderators immediately")
        await log_channel.send(f':red_circle: Member {ctx.author.mention} provided an invalid Patreon when calling the'
                               f' patreon_name command.')
    else:
        await log_channel.send(f'Member {ctx.author.mention} has been verified')
        await ctx.author.send(":white_check_mark: You've been verified!")
        record_discord_member(name, discord_id)


@client.command(pass_context=True)
async def kick_invalid_members(ctx):
    # If the user that called the command has permission, loop over every member and check if their data is logged
    # If not, kick them
    log_channel = client.get_channel(LOG_CHANNEL)
    if MODERATOR_ROLE.lower() in [i.name.lower() for i in ctx.author.roles]:
        members = ctx.guild.members
        data = get_discord_members()
        for member in members:
            if MODERATOR_ROLE.lower() not in [i.name.lower() for i in member.roles]:
                found = False
                for item in data:
                    if int(item[1]) == member.id:
                        found = True
                if not found:
                    await member.kick(reason="You did not validate your patreon. Please rejoin the server and submit a valid one.")
                    await ctx.send(f'Member {member.mention} was kicked.')
    else:
        await log_channel.send(f'User {ctx.author.mention} used the kick_invalid_members command without permission.')


client.run('ODQ3NTk2Mjc2NDg4NjAxNjEw.YLAXiw.fuY7Cd6L46_QtGkiiU9FoPvgaTA')
